import React from 'react'

function TaskBar() {
  return (
  //   <div>
  //     <nav className="navbar bg-light">
  //       <div className="container-fluid " style={{backgroundColor:'grey'}}>
  //           <span className="navbar-brand mb-0 h1 var(--bs-body-font-family); ">Shift Production Manager Form</span>
  //           <button type="button" className="btn-close" aria-label="Close"></button>
  //       </div>
  //       </nav>
  // </div>
  <div className='row mt-1'>
      <h4 className="form-title">Shift Production Manager Form</h4>
      <hr className="horizontal-line" />
  </div>
  )
}

export default TaskBar
