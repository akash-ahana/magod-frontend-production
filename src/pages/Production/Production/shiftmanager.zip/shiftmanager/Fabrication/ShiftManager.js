import React from 'react'
import Forms from './Forms'
import TaskBar from './TaskBar'

function ShiftManager() { 
  return (
    <div>
      <TaskBar/>
      <Forms/>
    </div>
  )
}

export default ShiftManager
